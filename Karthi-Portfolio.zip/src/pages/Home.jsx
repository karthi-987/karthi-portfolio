import React, { useState, Suspense, useEffect, useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import Loader from '../components/Loader';
import HomeInfo from '../components/HomeInfo';

import Island from '../models/Island';
import Sky from '../models/Sky';
import Bird from '../models/Bird';
import Plane from '../models/Plane';

import sakura from '../assets/sakura.mp3'
import { soundoff, soundon } from '../assets/icons';




const Home = () => {
  const audioref = useRef(new Audio(sakura));
  audioref.current.volume = 0.4;
  audioref.current.loop = true;

  const [isRotating, setIsRotating] = React.useState(false);
  const [currentStage, setCurrentStage] = useState(1); // 1: Island, 2: Plane
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  useEffect(() => {
    if(isPlayingMusic)
    {
      audioref.current.play();
    }
    return () => {
      audioref.current.pause();
    }

  }, [isPlayingMusic])

  const adjustIslandForScreenSize = () => {
    let screenScale = [0.9, 0.9, 0.9];
    let screenPosition = [0, -6.5, -70];
    let rotation = [0.1, 4.7, 0];

    if (window.innerWidth < 768) {
      screenScale = [0.75, 0.75, 0.75];
      screenPosition = [0, -5.5, -30];
    }
    else
    {
      screenScale = [0.9, 0.9, 0.9];
    }

    return [screenScale, screenPosition, rotation];
  }


  const adjustPlaneForScreenSize = () => {
    let screenScale, screenPosition; 


    if (window.innerWidth < 768) {
      screenScale = [1.3, 1.3, 1.3];
      screenPosition = [1.5, 0, -5];
    }
    else
    {
      screenScale = [2.5, 2.5, 2.5];
      screenPosition = [2, -3, -12];
    }
    return [screenScale, screenPosition];
  }




  const [islandScale, islandPosition, islandRotation] = adjustIslandForScreenSize();

  const [planeScale, planePosition] = adjustPlaneForScreenSize();

  return (
    <section className = "w-full h-screen relative">

    <div className = "absolute top-28 left-0 right-0 z-10 flex items-center justify-center">
        {currentStage && <HomeInfo currentStage={currentStage} />}
    </div>

        <Canvas
          className = {`w-full h-screen bg-transparent ${isRotating ? 'cursor-grabbing' : 'cursor-grab'}`}
          camera = {{position: [0, 0, 5], fov: 45, near: 0.1, far: 1000}}
          gl = {{alpha: true, antialias: true}}
        >

          <Suspense fallback = {<Loader />}>
            <directionalLight position = {[1, 1, 1]} intensity = {2} />
            <ambientLight intensity = {0.5} />
            <hemisphereLight skyColor = "#b1e1ff" groundColor = "#000000" intensity = {1} />


            <Bird />
            <Sky isRotating={isRotating} />

            <Island 
              position = {islandPosition}
              scale = {islandScale}
              rotation = {islandRotation}
              isRotating = {isRotating}
              setIsRotating = {setIsRotating}
              setCurrentStage = {setCurrentStage}
            />

            <Plane 
              isRotating = {isRotating}
              position = {planePosition}
              scale = {planeScale}
              rotation = {[0, 20, 0]}
            />
          </Suspense>

        </Canvas>

        <div className="absolute bottom-2 left-2">
          <img 
            src = { !isPlayingMusic ? soundoff : soundon}
            alt = "sound"
            className= "w-10 h-10 cursor-pointer object-contain"
            onClick = {() => setIsPlayingMusic(!isPlayingMusic)}
          />
        </div>
    </section>
  )
}

export default Home